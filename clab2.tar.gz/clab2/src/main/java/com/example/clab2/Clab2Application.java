package com.example.clab2;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@SpringBootApplication
public class Clab2Application {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        SpringApplication.run(Clab2Application.class, args);

        ClassPathXmlApplicationContext ac = new ClassPathXmlApplicationContext("TeastBean.xml");
        List<Department> departments = new ArrayList<>(); // Create a list to hold multiple departments
        
        while (true) {
            System.out.println("1. Insert Department details");
            System.out.println("2. Display Departments with College details");
            System.out.println("3. Exit");
            System.out.println("Enter your choice:");
            int choice = sc.nextInt();
            
            switch (choice) {
                case 1:
                    Department department = (Department) ac.getBean("department"); // Create a new Department object
                    System.out.println("Enter the Department name:");
                    department.setName(sc.next());
                    System.out.println("Enter the Department no:");
                    department.setId(sc.nextInt());
                    System.out.println("Enter the Department Description:");
                    department.setDescription(sc.next());
                    System.out.println("Thanks for input");
                    departments.add(department); // Add the department to the list
                    break;
                case 2:
                    System.out.println("Department Details:");
                    for (Department d : departments) { // Iterate through the list of departments
                        System.out.println("Name: " + d.getName() + " ID: " + d.getId() +
                                " Department Description: " + d.getDescription());
                        System.out.println("College Details");
                        College c = d.getCollege();
                        System.out.println("College Name: " + c.getName());
                        System.out.println("College Address: " + c.getAddress());
                    }
                    break;
                case 3:
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
                    break;
            }
        }
    }
}
