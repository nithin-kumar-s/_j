package com.example.clab4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Clab4Application {

	public static void main(String[] args) {
		SpringApplication.run(Clab4Application.class, args);
	}

}
