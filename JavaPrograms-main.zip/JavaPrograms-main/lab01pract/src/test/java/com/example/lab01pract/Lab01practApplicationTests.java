package com.example.lab01pract;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lab01practApplicationTests {

	@Test
	void contextLoads() {
	}

}
