package com.example.lab03pract;

public class Book {
int BId;
String BTitle,BAuthor;
int BPYear;
public int getBId() {
	return BId;
}
public void setBId(int bId) {
	BId = bId;
}
public String getBTitle() {
	return BTitle;
}
public void setBTitle(String bTitle) {
	BTitle = bTitle;
}
public String getBAuthor() {
	return BAuthor;
}
public void setBAuthor(String bAuthor) {
	BAuthor = bAuthor;
}
public int getBPYear() {
	return BPYear;
}
public void setBPYear(int bPYear) {
	BPYear = bPYear;
}
}
